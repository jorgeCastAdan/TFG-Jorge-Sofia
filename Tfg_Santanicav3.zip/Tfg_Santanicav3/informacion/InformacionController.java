package jorge.sofia.informacion;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import clases.Informacion;
import jorge.sofia.usuarios.UsuarioController;

/**
* Esta clase sirve para conectar la clase Informacion a la tabla de Informacion ademas de definir las rutas que va a
* tener la API para acceder a la informacion de la tabla.
* 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.1
*/

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/santanica/informacion")
public class InformacionController {
	
	private final Logger LOG = LoggerFactory.getLogger(UsuarioController.class);
	private final InformacionService servicio;
	
	public InformacionController(InformacionService servicio) {
		this.servicio = servicio;
	}
	
	/**
	 * Este metodo devuelve todos los objetos que se encuentren en la tabla Informacion
	 * @return - una lista de informaciones que haya encontrado en la base de datos y codigo 200 o codigo 404 si no ha encontrado ninguna ocurrencia
	 */
	@GetMapping
	public ResponseEntity<List<Informacion>> getTodos(){
		List<Informacion> buscadas = servicio.recuperarTodos();
		LOG.debug("Se han solicitado una lista de los objetos informacion");
		if(buscadas.isEmpty()) {
			LOG.warn("No se han podido recuperar o la tabla esta vacia");
			return ResponseEntity.notFound().build();
		} else {
			LOG.info("Informacion recuperada correctamente, devolviendolas...");
			return ResponseEntity.ok(buscadas);
		}
	}
	
	/**
	 * Este metodo busca en la base de datos por codigo.
	 * @param id - cadena que identifica a un objeto Informacion el cual se quiere buscar
	 * @return - codigo 200 en caso de haber encontrado el objeto informacion (junto a dicho objeto) o codigo 404 en caso de no haberlo encontrado
	 */
	@GetMapping("/id/{id}")
	public ResponseEntity<Informacion> getPorId(@PathVariable String id){
		Informacion buscado = servicio.recuperarPorCodigo(id);
		if(buscado != null) {
			return ResponseEntity.ok(buscado);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	/**
	 * Este metodo sirve para dar de alta un objeto Informacion en la base de datos.
	 * @param nueva - objeto informacion en formato JSON que va a ser insertado en la BD.
	 * @return - objeto con la nueva instancia de informacion y un codigo de como ha ido la operacion.
	 */
	@PostMapping("/nuevo")
	public ResponseEntity<Informacion> almacenarInformacion(@RequestBody Informacion info){
		Informacion nueva = servicio.guardarInformacion(info);
		return ResponseEntity.status(HttpStatus.CREATED).body(nueva);
	}
	
	/**
	 * Este metodo sirve para borrar una Informacion por su codigo.
	 * @param borrar - codigo o id que identifica a el objeto Informacion que se quiere brorar
	 * @return - codigo 204 en caso de haber borrado correctamente el objeto y 404 en caso de no haberla encontrado y no haberla podido borrar.
	 */
	@DeleteMapping("/borrar/{borrar}")
	public ResponseEntity<Informacion> borrarInformacion(@PathVariable String borrar){
		LOG.info("Se va a borrar la informacion con el codigo {" + borrar + "}");
		if(servicio.deleteInformacion(borrar)) {
			LOG.info("Se ha borrado con exito la informacion.");
			return ResponseEntity.noContent().build();
		} else {
			LOG.warn("No se ha encontrado la informacion con ese codigo, no se borrara nada.");
			return ResponseEntity.notFound().build();
		}
		
	}
	
}
