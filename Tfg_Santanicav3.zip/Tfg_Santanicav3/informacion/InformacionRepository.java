package jorge.sofia.informacion;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;

import clases.Informacion;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase InformacionService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

@EnableScan
public interface InformacionRepository extends CrudRepository<Informacion, String>{
	
	Informacion findByCodigo(String codigo);

}
