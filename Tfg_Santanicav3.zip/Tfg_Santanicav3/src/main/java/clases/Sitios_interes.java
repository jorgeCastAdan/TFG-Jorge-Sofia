package clases;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


/**
 * Esta clase representa la entidad Sitios_interes que corresponde con la tabla Sitios_interes de la base de datos.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 2.1
 */

@Entity
@Table(name = "sitios_interes")
public class Sitios_interes implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column(name = "id_sitios")
	private String codigo;
	
	@Column(name = "direccion")
	private String direccion;
	
	@Column(name = "lugar")
	private String lugar;
	
	@Column(name = "img")
	private String img;
	
	@Column(name = "informacion")
	private String informacion;
	
	@Column(name = "lat")
	private String latitud;
	
	@Column(name = "lon")
	private String longitud;
	
	@Column(name = "telefono")
	private String telefono;
	
	@Column(name = "valoracion")
	private String valoracion;
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDireccion() {
		return direccion;
	}
	
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getImg() {
		return img;
	}
	
	public void setImg(String img) {
		this.img = img;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public String getInformacion() {
		return informacion;
	}
	
	public void setInformacion(String informacion) {
		this.informacion = informacion;
	}

	public String getLatitud() {
		return latitud;
	}
	
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}

	public String getLongitud() {
		return longitud;
	}
	
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}

	public String getTelefono() {
		return telefono;
	}
	
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getValoracion() {
		return valoracion;
	}
	
	public void setValoracion(String valoracion) {
		this.valoracion = valoracion;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(codigo, direccion, latitud, longitud);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sitios_interes other = (Sitios_interes) obj;
		return Objects.equals(codigo, other.codigo) && Objects.equals(direccion, other.direccion)
				&& Objects.equals(latitud, other.latitud) && Objects.equals(longitud, other.longitud);
	}

	@Override
	public String toString() {
		return "Sitios_interes [codigo=" + codigo + ", direccion=" + direccion + ", lugar=" + lugar + ", img=" + img
				+ ", informacion=" + informacion + ", latitud=" + latitud + ", longitud=" + longitud + ", telefono="
				+ telefono + ", valoracion=" + valoracion + "]";
	}
	
}
