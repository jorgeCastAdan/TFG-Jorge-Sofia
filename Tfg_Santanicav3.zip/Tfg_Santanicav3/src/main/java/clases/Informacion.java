package clases;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Esta clase representa la entidad Informacion que corresponde con la tabla Informacion de la base de datos.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 2.1
 */

@Entity
@Table(name = "informacion")
public class Informacion implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column(name = "id_informacion")
	private String codigo;
	
	@Column(name = "descripcion")
	private String descripcion;
	
	@Column(name = "titulo")
	private String titulo;
	
	@Column(name = "imagen")
	private String imagen;

	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getImagen() {
		return imagen;
	}
	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(codigo, descripcion, titulo);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Informacion other = (Informacion) obj;
		return Objects.equals(codigo, other.codigo) && Objects.equals(descripcion, other.descripcion)
				&& Objects.equals(titulo, other.titulo);
	}
	
	@Override
	public String toString() {
		return "Informacion [codigo=" + codigo + ", descripcion=" + descripcion + ", titulo=" + titulo + ", imagen="
				+ imagen + "]";
	}
	
}
