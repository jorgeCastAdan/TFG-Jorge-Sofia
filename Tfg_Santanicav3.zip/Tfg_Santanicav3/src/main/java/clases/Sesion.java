package clases;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Esta clase representa la entidad Sesion que corresponde con la tabla Sesiones de la base de datos.
 *
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 2.1
 */

@Entity
@Table(name = "sesiones")
public class Sesion implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "token")
	private String token;
	
	@Column(name = "ttl")
	private Integer ttl;
	
	@Column(name = "email")
	private String email;
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}

	public Integer getTtl() {
		return ttl;
	}
	public void setTtl(Integer ttl) {
		this.ttl = ttl;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(email, token, ttl);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sesion other = (Sesion) obj;
		return Objects.equals(email, other.email) && Objects.equals(token, other.token)
				&& Objects.equals(ttl, other.ttl);
	}
	
	@Override
	public String toString() {
		return "Sesion [token=" + token + ", ttl=" + ttl + ", email=" + email + "]";
	}
	
}
