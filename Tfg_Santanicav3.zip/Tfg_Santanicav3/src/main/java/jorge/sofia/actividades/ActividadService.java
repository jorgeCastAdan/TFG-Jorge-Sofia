package jorge.sofia.actividades;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import clases.Actividad;

/**
 * Esta clase es usada para la definicion de los metodos de la interfaz de ActividadRepository y definir algunos adicionales a dicha clase
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.1
 */

@Service
public class ActividadService {
	
	@Autowired
	private ActividadRepository repositorio;
	
	public Actividad buscarPorCodigo(UUID cod){
		return repositorio.findByCodigo(cod);
	}
	
	public List<Actividad> recuperarTodos(){
		return (List<Actividad>)repositorio.findAll();
	}
	
	public Actividad almacenarActividad(Actividad a) {
		return repositorio.save(a);
	}
	
	public boolean deleteActvidad (UUID codigo) {
		Actividad a = this.buscarPorCodigo(codigo);
		if(a != null) {
			repositorio.delete(a);
			return true;
		} else {
			return false;
		}
			
	}
	
}
