package jorge.sofia.actividades;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import clases.Actividad;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase ActividadService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

public interface ActividadRepository extends JpaRepository<Actividad, UUID>{
	
	Actividad findByCodigo(UUID codigo);
	
}
