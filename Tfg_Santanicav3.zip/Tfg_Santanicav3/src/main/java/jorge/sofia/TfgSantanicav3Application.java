package jorge.sofia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Esta clase es la clase principal que Spring ejecuta para levantar la API y leer el resto de clases del proyecto
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

@SpringBootApplication
@EntityScan(basePackages = {"clases"})
@EnableJpaRepositories(basePackages = {"jorge.sofia.*"})
public class TfgSantanicav3Application {

	public static void main(String[] args) {
		SpringApplication.run(TfgSantanicav3Application.class, args);
	}

}
