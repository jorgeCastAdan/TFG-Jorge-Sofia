package jorge.sofia.usuarios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import clases.Usuario;

/**
 * Esta clase es usada para la definicion de los metodos de la interfaz de UsuarioRepository y definir algunos adicionales a dicha clase
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.4
 */

@Service
public class UsuarioService {
	
	@Autowired
	public UsuarioRepository repositorio;
	
	public Usuario buscarPorEmail(String email) {
		return repositorio.findByEmail(email);
	}
	
	public List<Usuario> getTodos(){
		return (List<Usuario>) repositorio.findAll();
	}
	
	public Usuario alamacenarUsuario(Usuario u) {
		return repositorio.save(u);
	}
	
	public boolean deleteUsuario (String email) {
		Usuario u = this.buscarPorEmail(email);
		if(u != null) {
			repositorio.delete(u);
			return true;
		} else {
			return false;
		}
			
	}
	
}
