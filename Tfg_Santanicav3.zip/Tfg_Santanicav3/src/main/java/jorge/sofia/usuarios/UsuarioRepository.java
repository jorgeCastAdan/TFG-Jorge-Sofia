package jorge.sofia.usuarios;

import org.springframework.data.jpa.repository.JpaRepository;

import clases.Usuario;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase UsuarioService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.4
 */

public interface UsuarioRepository extends JpaRepository<Usuario, Integer>{
	
	public Usuario findByEmail(String email);
	
	
}
