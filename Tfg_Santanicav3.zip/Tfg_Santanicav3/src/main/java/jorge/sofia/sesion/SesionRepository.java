package jorge.sofia.sesion;

import org.springframework.data.jpa.repository.JpaRepository;

import clases.Sesion;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase SesionService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

public interface SesionRepository extends JpaRepository<Sesion, String>{

	Sesion findByToken(String token);
}
