package jorge.sofia.informacion;

import org.springframework.data.jpa.repository.JpaRepository;

import clases.Informacion;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase InformacionService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

public interface InformacionRepository extends JpaRepository<Informacion, String>{
	
	Informacion findByCodigo(String codigo);

}
