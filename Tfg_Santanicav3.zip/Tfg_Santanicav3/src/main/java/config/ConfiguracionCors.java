package config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Esta clase se usa para que el proyecto de angular pueda acceder a la API cuando estén corriendo ambos en local.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

@Configuration
public class ConfiguracionCors implements WebMvcConfigurer {
	
	/**
	 * Este metodo sirve para definir la cabecera del endpoint de la API, dar acceso a el servicio corriendo en el 4200 (angular)
	 * acceso de todos los metodos de la API.
	 */
	@Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/santanica/**").allowedOrigins("http://localhost:4200").allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS").allowedHeaders("*");
    }

}
