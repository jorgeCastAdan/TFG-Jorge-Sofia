package jorge.sofia.actividades;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;

import clases.Actividad;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase ActividadService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

@EnableScan
public interface ActividadRepository extends CrudRepository<Actividad, String>{
	
	Actividad findByCodigo(String codigo);
	
}
