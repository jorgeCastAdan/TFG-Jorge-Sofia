package jorge.sofia.sesion;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;

import clases.Sesion;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase SesionService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

@EnableScan
public interface SesionRepository extends CrudRepository<Sesion, String>{

	Sesion findByToken(String token);
}
