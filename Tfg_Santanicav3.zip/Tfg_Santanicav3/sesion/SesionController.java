package jorge.sofia.sesion;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import clases.Sesion;

/**
* Esta clase sirve para conectar la clase Sesion a la tabla de Sesion ademas de definir las rutas que va a
* tener la API para acceder a la informacion de la tabla.
* 
* 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
*/

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/santanica/sesion")
public class SesionController {
	
	private final Logger LOG = LoggerFactory.getLogger(SesionController.class);
	private final SesionService servicio;
	
	public SesionController(SesionService servicio) {
		this.servicio = servicio;
	}
	
	/**
	 * Este metodo busca en la base de datos por codigo.
	 * @param id - cadena que identifica a un objeto Sesion el cual se quiere buscar
	 * @return - codigo 200 en caso de haber encontrado el objeto sesion (junto a dicho objeto) o codigo 404 en caso de no haberlo encontrado
	 */
	@GetMapping("/id/{id}")
	public ResponseEntity<Sesion> getPorToken(@PathVariable String id){
		Sesion buscada = servicio.getPorToken(id);
		LOG.info("Se ha pedido buscar una sesion por el id {" + id + "}");
		if(buscada != null) {
			LOG.info("Se ha encontrado la sesion, devolviendola...");
			return ResponseEntity.ok(buscada);
		} else {
			LOG.warn("No se ha encontrado la sesion con id {" + id + "}");
			return ResponseEntity.notFound().build();
		}
	}
	
	/**
	 * Este metodo devuelve todos los objetos que se encuentren en la tabla Sesion
	 * @return - una lista de sesiones que haya encontrado en la base de datos y codigo 200 o codigo 404 si no ha encontrado ninguna ocurrencia
	 */
	@GetMapping
	public ResponseEntity<List<Sesion>> getTodos(){
		List<Sesion> actividades = servicio.recuperarTodos();
		LOG.debug("Se ha solicitado listar todas las sesion.");
		if(actividades.isEmpty()) {
			LOG.warn("No se han podido devolver o no se han encontrado sesion.");
			return ResponseEntity.notFound().build();
		} else {
			LOG.info("Devolviendo una lista de las sesion...");
			return ResponseEntity.ok(actividades);
		}
	}
	
	/**
	 * Este metodo sirve para dar de alta un objeto Sesion en la base de datos.
	 * @param nueva - objeto sesion en formato JSON que va a ser insertado en la BD.
	 * @return - objeto con la nueva instancia de sesion y un codigo de como ha ido la operacion.
	 */
	@PostMapping("/nuevo")
	public ResponseEntity<Sesion> guardarSesion(@RequestBody Sesion nueva){
		LOG.info("Se va a almacenar una nueva sesion. {" + nueva.toString() + "}");
		Sesion guardar = servicio.guardarSesion(nueva);
		LOG.info("Se ha guardado correctamente la sesion.");
		return ResponseEntity.status(HttpStatus.CREATED).body(guardar);
	}
	
	/**
	 * Este metodo sirve para borrar una Sesion por su codigo.
	 * @param borrar - codigo o id que identifica a el objeto Sesion que se quiere brorar
	 * @return - codigo 204 en caso de haber borrado correctamente el objeto y 404 en caso de no haberla encontrado y no haberla podido borrar.
	 */
	@DeleteMapping("/borrar/{borrar}")
	public ResponseEntity<Sesion> borrarSesion(@PathVariable String borrar){
		LOG.info("Se va a borrar la sesion con el token {" + borrar + "}");
		if(servicio.deleteSesion(borrar)) {
			LOG.info("Se ha borrado correctamente el token.");
			return ResponseEntity.noContent().build();
		} else {
			LOG.warn("No se ha encontrado el token, no se borrara nada.");
			return ResponseEntity.notFound().build();
		}
		
	}
	
}
