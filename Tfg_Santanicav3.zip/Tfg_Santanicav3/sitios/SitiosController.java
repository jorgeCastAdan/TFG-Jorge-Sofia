package jorge.sofia.sitios;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import clases.Sitios_interes;

/**
* Esta clase sirve para conectar la clase Sitios_interes a la tabla de Sitios de interes ademas de definir las rutas que va a
* tener la API para acceder a la informacion de la tabla.
* 
* 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
*/

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/santanica/sitios")
public class SitiosController {
	private final Logger LOG = LoggerFactory.getLogger(SitiosController.class);
	private final SitiosService servicio;
	
	public SitiosController(SitiosService servicio) {
		this.servicio = servicio;
	}
	
	/**
	 * Este metodo devuelve todos los objetos que se encuentren en la tabla Sitios_interes
	 * @return - una lista de sitios que haya encontrado en la base de datos y codigo 200 o codigo 404 si no ha encontrado ninguna ocurrencia
	 */
	@GetMapping
	public ResponseEntity<List<Sitios_interes>> getTodos(){
		LOG.info("Se van a recuperar todos los sitios de interes");
		List<Sitios_interes> sitios = servicio.buscarTodos();
		if(sitios.isEmpty()) {
			LOG.error("No se han podido recuperar los sitios de interes");
			return ResponseEntity.notFound().build();
		} else {
			return ResponseEntity.ok(sitios);
		}
	}
	
	/**
	 * Este metodo busca en la base de datos por codigo.
	 * @param id - cadena que identifica a un objeto Sitios_interes el cual se quiere buscar
	 * @return - codigo 200 en caso de haber encontrado el objeto sitio (junto a dicho objeto) o codigo 404 en caso de no haberlo encontrado
	 */
	@GetMapping("/id/{codigo}")
	public ResponseEntity<Sitios_interes> getPorCodigo(@PathVariable String codigo){
		LOG.info("Se va a buscar en la tabla de sitios de interes por el codigo {" + codigo + "}");
		Sitios_interes buscado = servicio.buscarPorCodigo(codigo);
		if(buscado != null) {
			LOG.info("Se ha encontrado el sitio con titulo {" + buscado.getLugar() + "}");
			return ResponseEntity.ok(buscado);
		} else {
			LOG.warn("No se ha encontrado el sitio de interes");
			return ResponseEntity.notFound().build();
		}
	}
	
	/**
	 * Este metodo sirve para dar de alta un objeto Sitios_interes en la base de datos.
	 * @param nueva - objeto sitio en formato JSON que va a ser insertado en la BD.
	 * @return - objeto con la nueva instancia de sitio y un codigo de como ha ido la operacion.
	 */
	@PostMapping("/nuevo")
	public ResponseEntity<Sitios_interes> guardarSitios(@RequestBody Sitios_interes nuevo){
		LOG.info("Se va a guardar un nuevo sitio de interes");
		Sitios_interes guardar = servicio.alamcenarSitios(nuevo);
		LOG.info("Se ha guardado correctamente el sitio de interes {" + nuevo.toString() + "}");
		return ResponseEntity.status(HttpStatus.CREATED).body(guardar);
	}
	
	/**
	 * Este metodo sirve para borrar un Sitios_interes por su codigo.
	 * @param borrar - codigo o id que identifica a el objeto Sitios_interes que se quiere brorar
	 * @return - codigo 204 en caso de haber borrado correctamente el objeto y 404 en caso de no haberla encontrado y no haberla podido borrar.
	 */
	@DeleteMapping("/borrar/{borrar}")
	public ResponseEntity<Sitios_interes> borrarSitios(@PathVariable String borrar){
		LOG.info("Se va a borrar el sitio con el codigo {" + borrar + "}");
		if(servicio.deleteSitios(borrar)) {
			LOG.info("Se ha borrado con exito el sitio de interes.");
			return ResponseEntity.noContent().build();
		} else {
			LOG.warn("No se ha encontrado el sitio con ese codigo, no se borrara nada.");
			return ResponseEntity.notFound().build();
		}
		
	}
	
}
