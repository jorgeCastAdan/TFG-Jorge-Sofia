package jorge.sofia.sitios;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;

import clases.Sitios_interes;

/**
 * Esta interfaz es usada para definir metodos especificos para usar en la clase SitiosService
 * en un contexto de persistencia con DynamoDB y la gestion de JPA.
 * 
 * @author Jorge Castellanos y Sofia Ubeda
 * @version 1.0
 */

@EnableScan
public interface SitiosRepository extends CrudRepository<Sitios_interes, String>{
	
	public Sitios_interes findByCodigo(String codigo);
	
}
